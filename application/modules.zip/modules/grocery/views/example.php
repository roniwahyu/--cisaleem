
	
    <!-- <div class="container white-bg"> -->
    	<!-- <div class="row"> -->
    		<!-- <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"> -->
				<?php echo $output; ?>
    			
    		<!-- </div> -->
    	<!-- </div> -->
    <!-- </div> -->

